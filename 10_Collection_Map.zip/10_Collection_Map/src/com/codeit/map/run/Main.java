package com.codeit.map.run;

import com.codeit.map.view.MenuView;

public class Main {
	public static void main(String[] args) {
		MenuView menuView = new MenuView();
		menuView.mainMenu();
	}
}
