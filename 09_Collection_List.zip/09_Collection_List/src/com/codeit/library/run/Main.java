package com.codeit.library.run;

import com.codeit.library.view.MenuView;

public class Main {
	
	public static void main(String[] args) {
		MenuView menuView = new MenuView();
		
		menuView.mainMenu(); //mainMenu()
	}
}

